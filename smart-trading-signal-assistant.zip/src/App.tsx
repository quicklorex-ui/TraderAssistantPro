import React, { useState, useEffect } from "react";
import TradingChart from "./components/TradingChart";
import MarketSentimentSection from "./components/MarketSentimentSection";
import TechnicalSignalsTable from "./components/TechnicalSignalsTable";
import OrderBookDepth from "./components/OrderBookDepth";
import { SmartSignalResponse, TechnicalIndicators, Candle } from "./types";
import { Search, TrendingUp, Cpu, Volume2, ShieldCheck, ArrowRight, RotateCcw, AlertTriangle } from "lucide-react";

const PRESET_TICKERS = ["BTCUSDT", "ETHUSDT", "AAPL", "NVDA", "TSLA", "EUR/USD"];

// Staggered loading checkpoints for reassuring trading state
const LOADING_MESSAGES = [
  "Synchronizing historical hourly trading candles...",
  "Running Technical indicators mathematical array (EMA 9/21/50/200, Bollinger Bands)...",
  "Evaluating volume-weight profile and institutional VWAP lines...",
  "Connecting to Gemini AI server with active Search Grounding...",
  "Grounding market sentiment indexes against active news headlines...",
  "Harmonizing order-book liquidity layers and bidding spreads...",
  "Finalizing Buy / Sell limits decision matrix..."
];

export default function App() {
  const [searchSymbol, setSearchSymbol] = useState("BTCUSDT");
  const [activeSymbol, setActiveSymbol] = useState("BTCUSDT");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Data retrieved from backend
  const [candles, setCandles] = useState<Candle[]>([]);
  const [indicators, setIndicators] = useState<TechnicalIndicators | null>(null);
  const [signal, setSignal] = useState<SmartSignalResponse | null>(null);

  // loading message rotation state
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);

  // Rotate loading instructions when downloading
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (loading) {
      timer = setInterval(() => {
        setLoadingMsgIdx(prev => (prev + 1) % LOADING_MESSAGES.length);
      }, 2000);
    } else {
      setLoadingMsgIdx(0);
    }
    return () => clearInterval(timer);
  }, [loading]);

  const loadAnalysis = async (symbolToLoad: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/analyze?symbol=${encodeURIComponent(symbolToLoad)}`);
      const payload = await response.json();
      
      if (payload.success) {
        setCandles(payload.candles);
        setIndicators(payload.indicators);
        setSignal(payload.signal);
        setActiveSymbol(payload.actualSymbol);
        setSearchSymbol(payload.actualSymbol);
      } else {
        setError(payload.error || "System was unable to analyze this symbol.");
      }
    } catch (err: any) {
      console.error(err);
      setError("Unable to reach the analytical terminal server. Please verify you have run 'restart_dev_server'.");
    } finally {
      setLoading(false);
    }
  };

  // Perform initial fetch on mount
  useEffect(() => {
    loadAnalysis(activeSymbol);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchSymbol.trim()) {
      loadAnalysis(searchSymbol.trim());
    }
  };

  // Calculate percentage close comparison relative to previous candle close
  const getDailyChange = () => {
    if (candles.length < 2) return { val: 0, isPos: true };
    const latest = candles[candles.length - 1].close;
    const prev = candles[candles.length - 2].close;
    const diff = latest - prev;
    const pct = (diff / prev) * 100;
    return {
      val: pct,
      isPos: pct >= 0,
      diff,
    };
  };

  const dailyChange = getDailyChange();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col antialiased selection:bg-indigo-100 selection:text-indigo-900 pb-12">
      
      {/* 1. TOP PANEL: BRANDING HEADER */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-200/80 px-4 py-3 sm:px-6 shadow-sm select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center text-white font-extrabold shadow-sm">
              <Cpu className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight text-slate-900 flex items-center gap-1.5 leading-none">
                Smart Trading Signal Assistant
              </h1>
              <p className="text-[10px] text-gray-400 font-sans mt-0.5 font-medium">
                Autonomous full-stack candlestick scanner & AI validation node
              </p>
            </div>
          </div>

          {/* SEARCH FORM INPUT & SUBMITS */}
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-1.5 w-full md:w-auto">
            <div className="relative flex-grow md:w-64 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search symbol (e.g., TSLA, BTCUSDT)"
                value={searchSymbol}
                onChange={e => setSearchSymbol(e.target.value)}
                disabled={loading}
                className="w-full pl-9 pr-3 py-1.5 text-xs font-mono font-medium rounded-xl border border-gray-300 focus:border-slate-800 focus:outline-none transition-all disabled:opacity-50"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !searchSymbol.trim()}
              className="cursor-pointer bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-semibold rounded-xl px-3.5 py-1.5 border border-slate-900 shadow hover:shadow-md transition-all active:scale-[0.98] disabled:opacity-50 flex items-center gap-1.5"
            >
              Analyze
            </button>
          </form>

        </div>
      </header>

      {/* 2. SUB HEADER: ACTIVE PRESET CHIPS */}
      <section className="bg-white border-b border-gray-100 py-2.5 px-4 sm:px-6 select-none">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-2.5 text-xs">
          <span className="text-gray-400 font-medium whitespace-nowrap">Asset Presets:</span>
          <div className="flex flex-wrap items-center gap-2">
            {PRESET_TICKERS.map(ticker => (
              <button
                key={ticker}
                onClick={() => {
                  setSearchSymbol(ticker);
                  loadAnalysis(ticker);
                }}
                disabled={loading}
                className={`cursor-pointer px-3 py-1 text-xs font-mono font-bold rounded-lg border transition-all ${
                  activeSymbol === ticker
                    ? "bg-slate-900 border-slate-900 text-white shadow-sm"
                    : "bg-gray-50 border-gray-200 text-slate-500 hover:bg-white hover:text-slate-800"
                }`}
              >
                {ticker}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. DYNAMIC CONTENT MAIN COMPARTMENT */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex-grow w-full relative">
        
        {/* LOADING PROGRESS MODAL GAUGE */}
        {loading && (
          <div className="absolute inset-x-4 sm:inset-x-6 top-6 bg-slate-50/90 backdrop-blur-sm z-20 rounded-2xl flex flex-col items-center justify-center p-12 py-24 select-none min-h-[500px]">
            <div className="flex flex-col items-center max-w-md text-center">
              
              {/* Spinner animation custom vector */}
              <div className="relative w-16 h-16 mb-6">
                <div className="absolute inset-0 rounded-full border-4 border-slate-200" />
                <div className="absolute inset-0 rounded-full border-4 border-slate-950 border-t-transparent animate-spin" />
              </div>

              <h3 className="text-slate-900 font-extrabold text-base tracking-tight">
                Synthesizing Ticker Asset Matrix
              </h3>
              
              <div className="w-64 bg-slate-200 h-1 rounded-full overflow-hidden mt-3 mb-4">
                <div className="h-full bg-indigo-600 rounded-full animate-[loading-bar_3s_infinite_linear]" style={{
                  backgroundImage: "linear-gradient(90deg, transparent 0%, #10b981 50%, transparent 100%)",
                  backgroundSize: "200% 100%"
                }} />
              </div>

              {/* Status rotation logs */}
              <p className="text-xs text-indigo-600 font-mono font-bold leading-relaxed px-4 animate-fade-in transition-all h-10">
                {LOADING_MESSAGES[loadingMsgIdx]}
              </p>

              <span className="text-[10px] text-gray-400 font-sans uppercase mt-2 block">
                Scanning target: <b className="text-slate-700 font-mono">{activeSymbol}</b>
              </span>
            </div>
          </div>
        )}

        {/* ERROR SCREEN DIALOG CARD */}
        {error && !loading && (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 md:p-8 flex items-start gap-4 mb-6">
            <AlertTriangle className="w-10 h-10 text-rose-500 flex-shrink-0" />
            <div>
              <h3 className="text-rose-800 font-extrabold text-base tracking-tight mb-1">
                Scan Error Triggered
              </h3>
              <p className="text-xs text-rose-700 leading-relaxed max-w-2xl font-medium">
                {error}
              </p>
              <div className="mt-4 flex items-center gap-3">
                <button
                  onClick={() => loadAnalysis(activeSymbol)}
                  className="cursor-pointer bg-slate-900 text-white font-sans text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 border border-slate-950 shadow"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Re-attempt Connection
                </button>
              </div>
            </div>
          </div>
        )}

        {/* METRICS INTERACTIVE TRADING MODULE GRID */}
        {!loading && indicators && signal && (
          <div className="space-y-6">
            
            {/* ACTIVE VALUE BAR ROW OVERVIEW */}
            <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-4 flex flex-wrap items-center justify-between gap-4 select-none">
              <div className="flex items-center gap-3.5">
                <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 text-white font-extrabold text-sm tracking-wide font-mono uppercase">
                  {activeSymbol}
                </div>
                <div>
                  <div className="text-xl font-black text-slate-900 font-mono">
                    ${indicators.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
                  </div>
                  <div className="flex items-center gap-1 text-[11px] font-semibold mt-0.5 font-mono">
                    <span className={dailyChange.isPos ? "text-emerald-600" : "text-rose-600"}>
                      {dailyChange.isPos ? "+" : ""}{dailyChange.diff.toFixed( dailyChange.diff > 2 ? 2 : 4 )} ({dailyChange.isPos ? "+" : ""}{dailyChange.val.toFixed(2)}%)
                    </span>
                    <span className="text-gray-400 font-sans">Relative to previous closing candle</span>
                  </div>
                </div>
              </div>

              {/* Instant decision recap badges */}
              <div className="flex items-center gap-4 text-xs font-sans">
                <div className="flex flex-col items-end">
                  <span className="text-gray-400 font-bold text-[10px] uppercase">RSI Zone</span>
                  <span className="text-slate-700 font-mono font-bold mt-0.5">{indicators.rsi.toFixed(1)}</span>
                </div>
                <div className="flex flex-col items-end border-l border-gray-100 pl-4">
                  <span className="text-gray-400 font-bold text-[10px] uppercase">Trend (ADX)</span>
                  <span className="text-slate-700 font-mono font-bold mt-0.5">{indicators.adx.toFixed(1)}</span>
                </div>
                <div className="flex flex-col items-end border-l border-gray-100 pl-4">
                  <span className="text-gray-400 font-bold text-[10px] uppercase">ATR Limit</span>
                  <span className="text-slate-700 font-mono font-bold mt-0.5">{indicators.atr.toFixed(4)}</span>
                </div>
              </div>
            </div>

            {/* FIRST ROW GRID: CHART + SENTIMENT ADVISORY */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <TradingChart candles={candles} symbol={activeSymbol} />
              <MarketSentimentSection signal={signal} />
            </div>

            {/* SECOND ROW GRID: INDICATOR S&R TABLES + DEEP ORDER BOOK */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <TechnicalSignalsTable indicators={indicators} />
              <OrderBookDepth price={indicators.price} liquidity={signal.liquidityAnalysis} />
            </div>

            {/* THIRD BLOCK: NARRATIVE INTEGRATION (AI DEEP REPORT) */}
            <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-6 select-none">
              
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3.5 mb-4">
                <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <Cpu className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900">Convergence Strategic Rationale</h4>
                  <p className="text-[10px] text-gray-400">AI multi-indicator consensus log</p>
                </div>
              </div>

              {/* Reasoning points bullet list */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {signal.reasoning.map((point, index) => (
                  <div key={index} className="flex gap-2.5 items-start p-3 border border-gray-50 rounded-xl bg-slate-50/30 text-xs text-slate-700 font-sans leading-relaxed transition-all hover:bg-slate-50">
                    <div className="w-5 h-5 rounded-full bg-slate-900 text-white font-extrabold text-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                      {index + 1}
                    </div>
                    <span>{point}</span>
                  </div>
                ))}
              </div>

              {/* Educational info overlay */}
              <div className="mt-5 p-3 rounded-lg bg-indigo-50/40 border border-indigo-100/50 flex gap-2 text-[10px] text-indigo-700 font-sans font-medium">
                <ShieldCheck className="w-4 h-4 flex-shrink-0 text-indigo-500" />
                <span>
                  <b>Advisory Disclaimer:</b> This terminal is an automated analysis generator merging technical mathematical candle profiles with Gemini AI Search grounded news reports. Market investments carry substantial financial risk. Past results calculated are not reliable predictors of future price direction. Implement correct protective stop limits at all times.
                </span>
              </div>

            </div>

          </div>
        )}

      </main>
    </div>
  );
}
