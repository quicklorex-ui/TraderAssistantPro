import React, { useState } from "react";
import { SmartSignalResponse } from "../types";
import { Compass, Flame, CheckCircle, Copy, Check, Info, Calendar } from "lucide-react";

interface MarketSentimentSectionProps {
  signal: SmartSignalResponse;
}

export default function MarketSentimentSection({ signal }: MarketSentimentSectionProps) {
  const { decision, confidence, entryPrice, takeProfit, stopLoss, estimatedWindow, estimatedDuration, sentiment, reasoning } = signal;
  const [copied, setCopied] = useState(false);

  // Determine signal accent color
  const getAccentColor = (dec: "BUY" | "SELL" | "HOLD") => {
    switch (dec) {
      case "BUY":
        return {
          bg: "bg-emerald-600",
          lightBg: "bg-emerald-50",
          border: "border-emerald-200",
          text: "text-emerald-700",
          badge: "bg-emerald-500 text-white shadow-emerald-200",
        };
      case "SELL":
        return {
          bg: "bg-rose-600",
          lightBg: "bg-rose-50",
          border: "border-rose-200",
          text: "text-rose-700",
          badge: "bg-rose-500 text-white shadow-rose-200",
        };
      default:
        return {
          bg: "bg-slate-500",
          lightBg: "bg-slate-50",
          border: "border-gray-200",
          text: "text-slate-600",
          badge: "bg-slate-500 text-white shadow-slate-100",
        };
    }
  };

  const accent = getAccentColor(decision);

  const handleCopyLevels = () => {
    const textToCopy = `Signal: ${decision} (${confidence}% Confident)
Entry Price: $${entryPrice.toFixed(4)}
Take Profit Target: $${takeProfit.toFixed(4)}
Stop Loss Target: $${stopLoss.toFixed(4)}
Window: ${estimatedWindow}
Duration: ${estimatedDuration}`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Maps score to horizontal margin layout %
  const sentimentPercentage = Math.round(Math.min(100, Math.max(0, sentiment.score)));

  return (
    <div className="space-y-5 lg:col-span-1">
      
      {/* 1. COMPREHENSIVE SIGNAL OVERVIEW CARD */}
      <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 relative overflow-hidden select-none">
        
        {/* Subtle decorative background glow corresponding to active trade signal direction */}
        <div className={`absolute top-0 right-0 w-32 h-32 rounded-full filter blur-3xl opacity-10 pointer-events-none ${accent.bg}`} />

        <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">Trade Execution Signal</h2>
            <p className="text-[11px] text-gray-400">Tactical decision execution card</p>
          </div>
          <span className="text-xs text-gray-400 font-mono flex items-center gap-1 font-medium bg-slate-50 px-2 py-0.5 rounded border border-gray-100">
            <Calendar className="w-3.5 h-3.5 text-slate-400" /> Live
          </span>
        </div>

        {/* PROMINENT SIGNAL DISPLAY */}
        <div className="flex items-center gap-4 py-1.5">
          <div className={`px-5 py-3 rounded-2xl font-black text-xl tracking-wider text-center flex flex-col justify-center items-center shadow-md min-w-[110px] ${accent.badge}`}>
            <span className="text-[10px] tracking-widest font-bold opacity-80 uppercase">Signal</span>
            {decision}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-medium text-slate-500">Confidence Score:</span>
              <strong className={`text-base font-bold font-mono ${accent.text}`}>{confidence}%</strong>
            </div>
            
            {/* Horizontal progress representation of Confidence */}
            <div className="w-48 bg-gray-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${accent.bg}`}
                style={{ width: `${confidence}%` }}
              />
            </div>
            
            <p className="text-[11px] text-gray-400 mt-1.5 leading-relaxed font-sans font-medium">
              Based on {reasoning.length} structural indicators and market news profiles.
            </p>
          </div>
        </div>

        {/* TIME FRAME AND RISK LOGISTICS */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-gray-100 text-xs">
          <div className="bg-slate-50 border border-gray-100 rounded-lg p-2.5">
            <span className="text-[10px] font-sans font-semibold uppercase tracking-wider text-slate-400">Entry window</span>
            <div className="text-slate-700 font-semibold font-sans mt-0.5 leading-tight">{estimatedWindow}</div>
          </div>
          <div className="bg-slate-50 border border-gray-100 rounded-lg p-2.5">
            <span className="text-[10px] font-sans font-semibold uppercase tracking-wider text-slate-400">Holding duration</span>
            <div className="text-slate-700 font-semibold font-sans mt-0.5 leading-tight">{estimatedDuration}</div>
          </div>
        </div>

      </div>

      {/* 2. PROTECTIVE RISK SPECIFICATIONS (TAKE PROFIT, STOP LOSS) */}
      <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 relative select-none">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">Target Entry & Limits</h2>
            <p className="text-[11px] text-gray-400">Protective take profit and stop loss prices</p>
          </div>
          <button
            onClick={handleCopyLevels}
            className="cursor-pointer font-sans text-[11px] text-slate-500 hover:text-slate-800 font-semibold bg-gray-50 hover:bg-gray-100 border border-gray-200/80 rounded-lg px-2 px-2.5 py-1 flex items-center gap-1.5 transition-all"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" /> Added
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Copy Levels
              </>
            )}
          </button>
        </div>

        <div className="space-y-3 font-mono">
          
          {/* Optimal Entry Target */}
          <div className="flex items-center justify-between p-3 rounded-xl border border-gray-100 bg-slate-50/50">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-sm" />
              <span className="text-xs font-sans text-slate-500">Optimal Entry Target</span>
            </div>
            <strong className="text-slate-800 text-sm font-bold">
              ${entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
            </strong>
          </div>

          {/* Take Profit Target */}
          <div className="flex items-center justify-between p-3 rounded-xl border border-emerald-100 bg-emerald-50/20">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-200" />
              <span className="text-xs font-sans text-slate-500">Take Profit Limit (TP)</span>
            </div>
            <strong className="text-emerald-600 text-sm font-bold">
              ${takeProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
            </strong>
          </div>

          {/* Stop Loss Target */}
          <div className="flex items-center justify-between p-3 rounded-xl border border-rose-100 bg-rose-50/20">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-200" />
              <span className="text-xs font-sans text-slate-500">Stop Loss Boundary (SL)</span>
            </div>
            <strong className="text-rose-600 text-sm font-bold">
              ${stopLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
            </strong>
          </div>

        </div>

      </div>

      {/* 3. FEAR & GREED SENTIMENT INDEX GAUGE CARD */}
      <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 select-none">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">News & Market Sentiment</h2>
            <p className="text-[11px] text-gray-400">Grounding index based on active news</p>
          </div>
          <Flame className="w-4 h-4 text-amber-500" />
        </div>

        {/* Sentiment Score Gauge Bar representation */}
        <div className="p-3 bg-slate-50 rounded-xl border border-gray-50 mt-1">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-sans font-medium">Index Score:</span>
            <div className="flex items-center gap-1.5">
              <strong className="text-sm font-black font-mono text-slate-700">{sentiment.score}</strong>
              <span className="px-2 py-0.5 rounded text-[10px] font-sans font-bold bg-amber-50 text-amber-700 border border-amber-200 uppercase tracking-wide">
                {sentiment.label}
              </span>
            </div>
          </div>

          {/* Horizontal multi-color bar line */}
          <div className="relative w-full h-2.5 rounded-full mt-3 bg-gradient-to-r from-red-500 via-amber-400 via-yellow-300 to-emerald-500 overflow-visible">
            
            {/* The Pointer representing metric percentage */}
            <div
              className="absolute -top-1.5 w-5 h-5 rounded-full border-2 border-white bg-slate-800 shadow shadow-slate-400 transition-all duration-1000 -ml-2.5"
              style={{ left: `${sentimentPercentage}%` }}
            />
          </div>

          <div className="flex justify-between text-[9px] text-gray-400 font-sans uppercase font-bold tracking-wider mt-3 px-1">
            <span>Extreme Fear</span>
            <span>Fear</span>
            <span>Neutral</span>
            <span>Greed</span>
            <span>Extreme Greed</span>
          </div>
        </div>

        {/* Sentiment Summary Text */}
        <p className="text-xs text-slate-600 leading-relaxed font-sans mt-3.5 px-1 flex gap-1.5 items-start">
          <Info className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
          <span>{sentiment.summary}</span>
        </p>

        {/* Grounding News Headlines */}
        <div className="mt-4 pt-3.5 border-t border-gray-100">
          <span className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wider block mb-2 px-1">
            Latest Researched Elements
          </span>
          <div className="space-y-2">
            {sentiment.keyNews.map((newsItem, index) => (
              <div key={index} className="flex gap-2 text-xs text-slate-600 font-sans leading-relaxed">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                <span>{newsItem}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
