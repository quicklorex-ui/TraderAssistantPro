import React, { useState, useEffect } from "react";
import { LiquidityAnalysis } from "../types";

interface OrderBookDepthProps {
  price: number;
  liquidity: LiquidityAnalysis;
}

interface OrderRow {
  price: number;
  amount: number;
  total: number;
}

export default function OrderBookDepth({ price, liquidity }: OrderBookDepthProps) {
  const [bids, setBids] = useState<OrderRow[]>([]);
  const [asks, setAsks] = useState<OrderRow[]>([]);
  const [livePrice, setLivePrice] = useState(price);

  // Sync with prop changes
  useEffect(() => {
    setLivePrice(price);
  }, [price]);

  // Generate dynamic, live-oscillating order rows based on actual price and spread margins
  useEffect(() => {
    const generateOrderBook = () => {
      const spread = liquidity.spreadPercent / 100;
      const baseBid = livePrice * (1 - spread / 2);
      const baseAsk = livePrice * (1 + spread / 2);

      const computedBids: OrderRow[] = [];
      const computedAsks: OrderRow[] = [];

      let cumBidTotal = 0;
      let cumAskTotal = 0;

      for (let i = 0; i < 5; i++) {
        const step = i * 0.001;
        const bPrice = baseBid * (1 - step);
        const bAmount = 0.5 + Math.random() * 4.5;
        cumBidTotal += bPrice * bAmount;

        computedBids.push({
          price: bPrice,
          amount: bAmount,
          total: cumBidTotal,
        });

        const aPrice = baseAsk * (1 + step);
        const aAmount = 0.5 + Math.random() * 4.5;
        cumAskTotal += aPrice * aAmount;

        computedAsks.push({
          price: aPrice,
          amount: aAmount,
          total: cumAskTotal,
        });
      }

      setBids(computedBids);
      setAsks(computedAsks);
    };

    generateOrderBook();

    // Create a real-time interval timer to simulate active bidding updates in the order book!
    // Triggers slight micro-adjustments to display size and price to feel completely alive.
    const interval = setInterval(() => {
      // Tiny price oscillation (e.g., ±0.01% of base price)
      const shake = 1 + (Math.random() - 0.5) * 0.00015;
      setLivePrice(prev => prev * shake);

      setBids(prevBids =>
        prevBids.map(bid => {
          const delta = (Math.random() - 0.5) * 0.15;
          const nextAmt = Math.max(0.1, bid.amount + delta);
          return {
            ...bid,
            price: bid.price * shake,
            amount: nextAmt,
          };
        })
      );

      setAsks(prevAsks =>
        prevAsks.map(ask => {
          const delta = (Math.random() - 0.5) * 0.15;
          const nextAmt = Math.max(0.1, ask.amount + delta);
          return {
            ...ask,
            price: ask.price * shake,
            amount: nextAmt,
          };
        })
      );
    }, 1800);

    return () => clearInterval(interval);
  }, [price, liquidity]);

  const maxTotal = bids.length > 0 && asks.length > 0
    ? Math.max(bids[bids.length - 1].total, asks[asks.length - 1].total)
    : 100;

  return (
    <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 flex flex-col h-full">
      <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-800">Order Book & Liquidity</h2>
          <p className="text-[11px] text-gray-400">Real-time depth and order density</p>
        </div>
        <div className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono text-slate-600 font-medium uppercase">
          Depth: {liquidity.depthLevel}
        </div>
      </div>

      {/* Depth Bars Wrapper */}
      <div className="flex flex-col flex-grow font-mono text-xs">
        {/* ASKS (SELL ORDERS) - Displayed from highest down to lowest ask */}
        <div className="flex flex-col gap-1 select-none">
          {/* Header */}
          <div className="grid grid-cols-3 text-[10px] text-gray-400 font-sans pb-1 px-1">
            <span>Price ({liquidity.spreadPercent < 0.2 ? "USD" : "Tick"})</span>
            <span className="text-right">Size</span>
            <span className="text-right">Cumulative</span>
          </div>

          {[...asks].reverse().map((ask, idx) => {
            const depthWidth = (ask.total / maxTotal) * 100;
            return (
              <div key={`ask-${idx}`} className="relative grid grid-cols-3 py-0.5 px-1 hover:bg-slate-50 transition-colors rounded">
                {/* Horizontal Depth visual bar */}
                <div
                  className="absolute right-0 top-0 bottom-0 bg-red-50/70"
                  style={{ width: `${depthWidth}%`, zIndex: 0 }}
                />
                <span className="text-rose-600 font-semibold z-10 z-[1]">{ask.price.toFixed(4)}</span>
                <span className="text-right text-slate-600 z-[1]">{ask.amount.toFixed(3)}</span>
                <span className="text-right text-slate-400 z-[1]">{Math.round(ask.total).toLocaleString()}</span>
              </div>
            );
          })}
        </div>

        {/* MIDDLE BAR: Current Spread and Ticker Pricing */}
        <div className="my-3 py-2.5 px-3 bg-slate-50 border-y border-gray-100 rounded-lg flex items-center justify-between select-none">
          <div className="flex flex-col">
            <span className="text-[10px] text-gray-400 font-sans uppercase tracking-wider">Spread</span>
            <span className="text-xs font-bold text-slate-700">{liquidity.spreadPercent.toFixed(3)}%</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-gray-400 font-sans uppercase tracking-wider">Live Price</span>
            <span className="text-sm font-bold text-slate-800 font-mono animate-pulse">
              ${livePrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
            </span>
          </div>
        </div>

        {/* BIDS (BUY ORDERS) - Displayed from highest bid down to lowest bid */}
        <div className="flex flex-col gap-1 select-none">
          {bids.map((bid, idx) => {
            const depthWidth = (bid.total / maxTotal) * 100;
            return (
              <div key={`bid-${idx}`} className="relative grid grid-cols-3 py-0.5 px-1 hover:bg-slate-50 transition-colors rounded">
                {/* Horizontal Depth visual bar */}
                <div
                  className="absolute right-0 top-0 bottom-0 bg-emerald-50/70"
                  style={{ width: `${depthWidth}%`, zIndex: 0 }}
                />
                <span className="text-emerald-600 font-semibold z-10 z-[1]">{bid.price.toFixed(4)}</span>
                <span className="text-right text-slate-600 z-[1]">{bid.amount.toFixed(3)}</span>
                <span className="text-right text-slate-400 z-[1]">{Math.round(bid.total).toLocaleString()}</span>
              </div>
            );
          })}
        </div>

        {/* 24h Volume details */}
        <div className="mt-auto pt-4 border-t border-gray-100 flex items-center justify-between font-sans text-[11px] text-slate-500">
          <span>Active Volume (24h)</span>
          <span className="font-mono font-semibold text-slate-700">
            {liquidity.volume24h > 1000000
              ? `${(liquidity.volume24h / 1000000).toFixed(2)}M`
              : liquidity.volume24h.toLocaleString()}{" "}
            units
          </span>
        </div>
      </div>
    </div>
  );
}
