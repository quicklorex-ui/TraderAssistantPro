import React from "react";
import { TechnicalIndicators } from "../types";
import { TrendingUp, TrendingDown, RefreshCw, Layers, ShieldCheck, Zap } from "lucide-react";

interface TechnicalSignalsTableProps {
  indicators: TechnicalIndicators;
}

export default function TechnicalSignalsTable({ indicators }: TechnicalSignalsTableProps) {
  const { price, ema9, ema21, ema50, ema200, rsi, macd, bollingerBands, stochastic, adx, atr, pivotPoints, localSwing } = indicators;

  // Helper to establish trend colors/direction for EMAs
  const getTrendElement = (emaVal: number) => {
    const isBullish = price > emaVal;
    return {
      label: isBullish ? "Bullish" : "Bearish",
      className: isBullish ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-rose-50 text-rose-700 border-rose-200",
      icon: isBullish ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />,
    };
  };

  // RSI status evaluation
  const getRsiStatus = (val: number) => {
    if (val > 70) return { label: "Overbought", className: "bg-red-100 text-red-800 border-red-300 animate-pulse" };
    if (val < 30) return { label: "Oversold", className: "bg-emerald-100 text-emerald-800 border-emerald-300 animate-pulse" };
    if (val > 50) return { label: "Bullish Zone", className: "bg-slate-50 text-slate-700 border-gray-200" };
    return { label: "Bearish Zone", className: "bg-slate-50 text-slate-700 border-gray-200" };
  };

  // Stochastic Oscillator status evaluation
  const getStochStatus = (k: number) => {
    if (k > 80) return { label: "Overbought Trigger", className: "bg-rose-50 text-rose-700 border-rose-200" };
    if (k < 20) return { label: "Oversold Trigger", className: "bg-emerald-50 text-emerald-700 border-emerald-200" };
    return { label: "Neutral Stoch", className: "bg-slate-50 text-slate-500 border-gray-100" };
  };

  // ADX trend strength evaluation
  const getAdxStrength = (val: number) => {
    if (val > 40) return { label: "Very Strong Trend", className: "text-amber-600 font-bold" };
    if (val > 25) return { label: "Strong Trend", className: "text-emerald-600 font-semibold" };
    if (val > 20) return { label: "Moderate Trend", className: "text-indigo-600" };
    return { label: "Range Bound / Flat", className: "text-slate-400 font-normal" };
  };

  return (
    <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 md:col-span-2">
      <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-800">Technical Signal Matrix</h2>
          <p className="text-[11px] text-gray-400">Mathematical indicators calculation logs</p>
        </div>
        <RefreshCw className="w-4 h-4 text-gray-300 animate-spin" style={{ animationDuration: "10s" }} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* LEFT COLUMN: TREND & MOMENTUM CARD */}
        <div className="space-y-4">
          
          {/* Trend Indicators block */}
          <div className="border border-gray-100 rounded-xl p-3 bg-slate-50/50">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-slate-500" /> Trend Indicators
            </span>
            <div className="mt-2.5 space-y-2 text-xs">
              
              {/* EMA list */}
              {[
                { name: "EMA (9) Short", val: ema9 },
                { name: "EMA (21) Short", val: ema21 },
                { name: "EMA (50) Medium", val: ema50 },
                { name: "EMA (200) Macro", val: ema200 },
              ].map((emaRow, idx) => {
                const status = getTrendElement(emaRow.val);
                return (
                  <div key={idx} className="flex items-center justify-between py-0.5 font-mono select-none">
                    <span className="text-slate-500 font-sans">{emaRow.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-700 font-medium">{emaRow.val.toFixed(2)}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-sans border flex items-center gap-0.5 ${status.className}`}>
                        {status.icon} {status.label}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* ADX Evaluation */}
              <div className="flex items-center justify-between pt-1 border-t border-gray-100 font-mono select-none">
                <span className="text-slate-500 font-sans">ADX Trend Power</span>
                <div className="flex flex-col items-end">
                  <span className="text-slate-700 font-semibold">{adx.toFixed(2)}</span>
                  <span className={`text-[10px] font-sans mt-0.5 ${getAdxStrength(adx).className}`}>
                    {getAdxStrength(adx).label}
                  </span>
                </div>
              </div>

            </div>
          </div>

          {/* Momentum Indicators block */}
          <div className="border border-gray-100 rounded-xl p-3 bg-slate-50/50">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-slate-500" /> Momentum Oscillators
            </span>
            <div className="mt-2.5 space-y-2.5 text-xs font-mono">
              
              {/* RSI (14) */}
              <div className="flex items-center justify-between py-0.5 select-none">
                <span className="text-slate-500 font-sans">RSI (14)</span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-800 font-semibold">{rsi.toFixed(2)}</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-sans border ${getRsiStatus(rsi).className}`}>
                    {getRsiStatus(rsi).label}
                  </span>
                </div>
              </div>

              {/* Stochastic K/D */}
              <div className="flex items-center justify-between py-0.5 select-none">
                <span className="text-slate-500 font-sans">Stochastic %K / %D</span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-700">{stochastic.k.toFixed(1)} / {stochastic.d.toFixed(1)}</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-sans border ${getStochStatus(stochastic.k).className}`}>
                    {getStochStatus(stochastic.k).label}
                  </span>
                </div>
              </div>

              {/* MACD Hist */}
              <div className="flex items-center justify-between py-0.5 select-none">
                <span className="text-slate-500 font-sans">MACD Histogram</span>
                <div className="flex items-center gap-2">
                  <span className={`font-semibold ${macd.histogram >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                    {macd.histogram.toFixed(4)}
                  </span>
                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-sans border ${macd.histogram >= 0 ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-rose-50 text-rose-700 border-rose-100"}`}>
                    {macd.histogram >= 0 ? "Bullish Cross" : "Bearish Cross"}
                  </span>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: S&R LEVELS & VOLATILITY */}
        <div className="space-y-4">
          
          {/* Support & Resistance Pivot Points block */}
          <div className="border border-gray-100 rounded-xl p-3 bg-slate-50/50">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-slate-500" /> S&R Classic Pivot Points
            </span>
            <div className="mt-2.5 grid grid-cols-2 gap-x-2 gap-y-1.5 text-xs font-mono select-none">
              
              <div className="p-1 px-2 border border-blue-100 bg-blue-50/30 rounded flex justify-between col-span-2">
                <span className="text-blue-500 font-sans">Daily Pivot (P)</span>
                <strong className="text-blue-700">{pivotPoints.p.toFixed(4)}</strong>
              </div>

              <div className="p-1 px-1.5 border border-rose-100 rounded flex justify-between">
                <span className="text-rose-400 font-sans">Res (R1)</span>
                <span className="text-rose-600 font-semibold">{pivotPoints.r1.toFixed(3)}</span>
              </div>
              <div className="p-1 px-1.5 border border-emerald-100 rounded flex justify-between">
                <span className="text-emerald-400 font-sans">Supp (S1)</span>
                <span className="text-emerald-600 font-semibold">{pivotPoints.s1.toFixed(3)}</span>
              </div>

              <div className="p-1 px-1.5 border border-rose-100 rounded flex justify-between">
                <span className="text-rose-400 font-sans">Res (R2)</span>
                <span className="text-rose-500">{pivotPoints.r2.toFixed(3)}</span>
              </div>
              <div className="p-1 px-1.5 border border-emerald-100 rounded flex justify-between">
                <span className="text-emerald-400 font-sans">Supp (S2)</span>
                <span className="text-emerald-500">{pivotPoints.s2.toFixed(3)}</span>
              </div>

              <div className="p-1 px-1.5 border border-rose-100 rounded flex justify-between">
                <span className="text-rose-400 font-sans">Res (R3)</span>
                <span className="text-rose-500">{pivotPoints.r3.toFixed(3)}</span>
              </div>
              <div className="p-1 px-1.5 border border-emerald-100 rounded flex justify-between">
                <span className="text-emerald-400 font-sans">Supp (S3)</span>
                <span className="text-emerald-500">{pivotPoints.s3.toFixed(3)}</span>
              </div>

            </div>
          </div>

          {/* Volatility & Vol Profile Block */}
          <div className="border border-gray-100 rounded-xl p-3 bg-slate-50/50">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-500" /> Volatility Indicators
            </span>
            <div className="mt-2.5 space-y-2 text-xs font-mono">
              
              {/* ATR absolute */}
              <div className="flex items-center justify-between select-none">
                <span className="text-slate-500 font-sans">Average True Range (ATR)</span>
                <strong className="text-slate-700">{atr.toFixed(4)}</strong>
              </div>

              {/* Bollinger Bands Spacing */}
              <div className="flex items-center justify-between pt-1 selection:border-t border-gray-100 select-none">
                <span className="text-slate-500 font-sans">BB Bands Bandwidth</span>
                <strong className="text-slate-700">
                  {((bollingerBands.upper - bollingerBands.lower) / bollingerBands.middle * 100).toFixed(2)}%
                </strong>
              </div>

              {/* Local Swings High/Low */}
              <div className="flex items-center justify-between select-none pt-1 border-t border-gray-100">
                <span className="text-slate-500 font-sans">20h Local Swing High</span>
                <strong className="text-emerald-600">{localSwing.high.toFixed(3)}</strong>
              </div>
              <div className="flex items-center justify-between select-none">
                <span className="text-slate-500 font-sans">20h Local Swing Low</span>
                <strong className="text-rose-600">{localSwing.low.toFixed(3)}</strong>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
