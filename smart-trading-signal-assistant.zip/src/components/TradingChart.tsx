import React, { useState, useMemo, useRef, useEffect } from "react";
import { Candle } from "../types";

interface TradingChartProps {
  candles: Candle[];
  symbol: string;
}

type BottomIndicatorType = "RSI" | "MACD" | "STOCH" | "ATR";

export default function TradingChart({ candles, symbol }: TradingChartProps) {
  // Chart Display Toggles
  const [showEma9, setShowEma9] = useState(true);
  const [showEma21, setShowEma21] = useState(true);
  const [showEma50, setShowEma50] = useState(false);
  const [showEma200, setShowEma200] = useState(false);
  const [showBB, setShowBB] = useState(true);
  const [showVwap, setShowVwap] = useState(true);
  
  // Selection of the secondary lower oscillator pane
  const [bottomIndicator, setBottomIndicator] = useState<BottomIndicatorType>("RSI");

  // Hover state variables for interactive legend and crosshair
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const [mouseCoords, setMouseCoords] = useState<{ x: number; y: number } | null>(null);

  // Dynamic dimensions of SVG
  const width = 800;
  const mainHeight = 280;
  const gap = 20;
  const subHeight = 100;
  const paddingRight = 60;
  const paddingLeft = 15;
  const paddingTop = 25;
  const paddingBottom = 20;

  const totalHeight = mainHeight + gap + subHeight + paddingTop + paddingBottom;

  // 1. Client-Side continuous Indicator Generation for all historical candle points
  const continuousIndicators = useMemo(() => {
    const n = candles.length;
    if (n === 0) return [];

    const closes = candles.map(c => c.close);
    
    // EMA helper
    const calcEMAArray = (period: number): number[] => {
      const k = 2 / (period + 1);
      const ema: number[] = [closes[0]];
      for (let i = 1; i < n; i++) {
        ema.push(closes[i] * k + ema[i - 1] * (1 - k));
      }
      return ema;
    };

    const ema9 = calcEMAArray(9);
    const ema21 = calcEMAArray(21);
    const ema50 = calcEMAArray(50);
    const ema200 = calcEMAArray(200);

    // Bollinger Bands (20, 2)
    const bbUpper: number[] = [];
    const bbLower: number[] = [];
    const bbMiddle: number[] = [];

    for (let i = 0; i < n; i++) {
      if (i < 19) {
        bbUpper.push(closes[i]);
        bbLower.push(closes[i]);
        bbMiddle.push(closes[i]);
      } else {
        const slice = closes.slice(i - 19, i + 1);
        const sum = slice.reduce((a, b) => a + b, 0);
        const sma = sum / 20;
        const variance = slice.reduce((v, val) => v + Math.pow(val - sma, 2), 0) / 20;
        const stdDev = Math.sqrt(variance);
        bbUpper.push(sma + 2 * stdDev);
        bbLower.push(sma - 2 * stdDev);
        bbMiddle.push(sma);
      }
    }

    // VWAP continuous
    const vwap: number[] = [];
    let cumPV = 0;
    let cumV = 0;
    for (let i = 0; i < n; i++) {
      const c = candles[i];
      const typ = (c.high + c.low + c.close) / 3;
      const v = c.volume || 1;
      cumPV += typ * v;
      cumV += v;
      vwap.push(cumPV / cumV);
    }

    // RSI 14 continuous
    const rsi: number[] = [50];
    let gains = 0;
    let losses = 0;
    for (let i = 1; i < Math.min(15, n); i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains += diff;
      else losses -= diff;
    }
    let avgGain = gains / 14;
    let avgLoss = losses / 14;
    if (avgLoss === 0) rsi.push(100);
    else rsi.push(100 - 100 / (1 + avgGain / avgLoss));

    for (let i = 2; i < n; i++) {
      if (i < 14) {
        rsi.push(50);
      } else {
        const diff = closes[i] - closes[i - 1];
        const g = diff > 0 ? diff : 0;
        const l = diff < 0 ? -diff : 0;
        avgGain = (avgGain * 13 + g) / 14;
        avgLoss = (avgLoss * 13 + l) / 14;
        if (avgLoss === 0) rsi.push(100);
        else rsi.push(100 - 100 / (1 + avgGain / avgLoss));
      }
    }

    // MACD continuous (12, 26, 9)
    const ema12 = calcEMAArray(12);
    const ema26 = calcEMAArray(26);
    const macdLine = ema12.map((val, i) => val - ema26[i]);
    const signalLine: number[] = [macdLine[0]];
    const kSig = 2 / (9 + 1);
    for (let i = 1; i < n; i++) {
      signalLine.push(macdLine[i] * kSig + signalLine[i - 1] * (1 - kSig));
    }
    const macdHist = macdLine.map((val, i) => val - signalLine[i]);

    // Stochastic continuous (14, 3, 3)
    const stochK: number[] = [];
    for (let i = 0; i < n; i++) {
      if (i < 13) {
        stochK.push(50);
      } else {
        const slice = candles.slice(i - 13, i + 1);
        const low = Math.min(...slice.map(c => c.low));
        const high = Math.max(...slice.map(c => c.high));
        const denom = high - low;
        stochK.push(denom === 0 ? 50 : ((closes[i] - low) / denom) * 100);
      }
    }
    const smoothK = stochK.map((val, i) => {
      if (i < 2) return val;
      return (stochK[i] + stochK[i - 1] + stochK[i - 2]) / 3;
    });
    const smoothD = smoothK.map((val, i) => {
      if (i < 2) return val;
      return (smoothK[i] + smoothK[i - 1] + smoothK[i - 2]) / 3;
    });

    // ATR continuous
    const atr: number[] = [candles[0].high - candles[0].low];
    for (let i = 1; i < n; i++) {
      atr.push(Math.max(
        candles[i].high - candles[i].low,
        Math.abs(candles[i].high - closes[i - 1]),
        Math.abs(candles[i].low - closes[i - 1])
      ));
    }
    const smoothAtr: number[] = [atr[0]];
    for (let i = 1; i < n; i++) {
      if (i < 14) {
        const slice = atr.slice(0, i + 1);
        smoothAtr.push(slice.reduce((a, b) => a + b, 0) / slice.length);
      } else {
        smoothAtr.push((smoothAtr[i - 1] * 13 + atr[i]) / 14);
      }
    }

    return candles.map((c, i) => ({
      time: c.time,
      ema9: ema9[i],
      ema21: ema21[i],
      ema50: ema50[i],
      ema200: ema200[i],
      bbUpper: bbUpper[i],
      bbMiddle: bbMiddle[i],
      bbLower: bbLower[i],
      vwap: vwap[i],
      rsi: rsi[i],
      macd: macdLine[i],
      macdSignal: signalLine[i],
      macdHist: macdHist[i],
      stochK: smoothK[i],
      stochD: smoothD[i],
      atr: smoothAtr[i],
    }));
  }, [candles]);

  // Coordinate scales calculations
  const drawableWidth = width - paddingLeft - paddingRight;

  const yRange = useMemo(() => {
    if (candles.length === 0) return { min: 0, max: 100 };
    let lows = candles.map(c => c.low);
    let highs = candles.map(c => c.high);
    
    // Add active overlays to expand coordinate limits so lines don't clip
    if (showBB && continuousIndicators.length > 0) {
      lows = lows.concat(continuousIndicators.map(ind => ind.bbLower));
      highs = highs.concat(continuousIndicators.map(ind => ind.bbUpper));
    }
    if (showEma200 && continuousIndicators.length > 0) {
      lows = lows.concat(continuousIndicators.map(ind => ind.ema200));
      highs = highs.concat(continuousIndicators.map(ind => ind.ema200));
    }

    const min = Math.min(...lows);
    const max = Math.max(...highs);
    const diff = max - min;
    // adding padding of 5% on top and bottom
    return {
      min: Math.max(0, min - diff * 0.05),
      max: max + diff * 0.05,
    };
  }, [candles, showBB, showEma200, continuousIndicators]);

  // Transform functions
  const getX = (index: number) => {
    if (candles.length <= 1) return paddingLeft;
    return paddingLeft + (index / (candles.length - 1)) * drawableWidth;
  };

  const getYPos = (price: number) => {
    const range = yRange.max - yRange.min;
    if (range === 0) return paddingTop + mainHeight / 2;
    const ratio = (price - yRange.min) / range;
    return paddingTop + mainHeight - ratio * mainHeight;
  };

  // SVG drawing paths based on memoized indicators
  const ema9Path = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.ema9).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const ema21Path = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.ema21).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const ema50Path = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.ema50).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const ema200Path = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.ema200).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const vwapPath = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.vwap).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const bbUpperPath = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.bbUpper).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  const bbLowerPath = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    return "M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.bbLower).toFixed(1)}`).join(" L ");
  }, [continuousIndicators, yRange]);

  // Shading zone between BB Upper & BB Lower
  const bbFillArea = useMemo(() => {
    if (continuousIndicators.length === 0) return "";
    const topCoords = continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getYPos(ind.bbUpper).toFixed(1)}`);
    const bottomCoords = [...continuousIndicators].reverse().map((ind, i) => {
      const revIndex = continuousIndicators.length - 1 - i;
      return `${getX(revIndex).toFixed(1)},${getYPos(ind.bbLower).toFixed(1)}`;
    });
    return "M " + topCoords.join(" L ") + " L " + bottomCoords.join(" L ") + " Z";
  }, [continuousIndicators, yRange]);

  // 2. Oscillators Y position mapper
  const getOscillatorY = (value: number, min: number, max: number) => {
    const range = max - min;
    const innerY = subHeight;
    const baseOffset = paddingTop + mainHeight + gap;
    if (range === 0) return baseOffset + innerY / 2;
    const ratio = (value - min) / range;
    return baseOffset + innerY - ratio * innerY;
  };

  // Active hover indicator index
  const activeIndex = hoverIndex !== null ? hoverIndex : candles.length - 1;
  const currentCandle = candles[activeIndex];
  const currentInd = continuousIndicators[activeIndex];

  // Mouse coordinate tracker to index mapper
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    if (!chartContainerRef.current) return;
    const rect = chartContainerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setMouseCoords({ x, y });

    // evaluate closest candle index
    const relativeX = x - paddingLeft;
    if (relativeX < 0) {
      setHoverIndex(0);
    } else if (relativeX > drawableWidth) {
      setHoverIndex(candles.length - 1);
    } else {
      const index = Math.round((relativeX / drawableWidth) * (candles.length - 1));
      setHoverIndex(Math.min(candles.length - 1, Math.max(0, index)));
    }
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
    setMouseCoords(null);
  };

  // Format Unix timestamp to time string
  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  };

  return (
    <div className="bg-white border border-gray-200/80 rounded-2xl shadow-sm p-5 flex flex-col md:col-span-3">
      {/* Chart Headers and Legend info */}
      <div className="flex flex-wrap items-center justify-between border-b border-gray-100 pb-3 mb-4">
        <div>
          <div className="flex items-center space-x-2 gap-1.5">
            <span className="text-sm font-semibold tracking-wide text-slate-800 uppercase px-2 py-0.5 bg-slate-100 rounded">
              {symbol}
            </span>
            <span className="text-xs text-gray-400 font-mono">1-Hour Candle Intervals</span>
          </div>
          
          {/* Candle details displayed dynamically on hovering */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 font-mono text-xs text-slate-600">
            <span>
              O: <strong className="text-slate-800">{currentCandle?.open.toFixed(2)}</strong>
            </span>
            <span>
              H: <strong className="text-emerald-600">{currentCandle?.high.toFixed(2)}</strong>
            </span>
            <span>
              L: <strong className="text-rose-600">{currentCandle?.low.toFixed(2)}</strong>
            </span>
            <span>
              C: <strong className={currentCandle?.close >= currentCandle?.open ? "text-emerald-600" : "text-rose-600"}>
                {currentCandle?.close.toFixed(2)}
              </strong>
            </span>
            <span>
              V: <strong className="text-indigo-600">{Math.round(currentCandle?.volume || 0).toLocaleString()}</strong>
            </span>
            <span className="text-gray-400 font-sans text-[11px] ml-auto">
              {formatDate(currentCandle?.time)} {formatTime(currentCandle?.time)}
            </span>
          </div>
        </div>

        {/* Toggles wrapper */}
        <div className="flex flex-wrap items-center gap-2 mt-2 sm:mt-0">
          <button
            onClick={() => setShowEma9(!showEma9)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showEma9 ? "bg-amber-50 border-amber-300 text-amber-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            EMA 9
          </button>
          <button
            onClick={() => setShowEma21(!showEma21)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showEma21 ? "bg-sky-50 border-sky-300 text-sky-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            EMA 21
          </button>
          <button
            onClick={() => setShowEma50(!showEma50)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showEma50 ? "bg-indigo-50 border-indigo-300 text-indigo-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            EMA 50
          </button>
          <button
            onClick={() => setShowEma200(!showEma200)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showEma200 ? "bg-rose-50 border-rose-300 text-rose-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            EMA 200
          </button>
          <button
            onClick={() => setShowBB(!showBB)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showBB ? "bg-purple-50 border-purple-300 text-purple-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            Bands
          </button>
          <button
            onClick={() => setShowVwap(!showVwap)}
            className={`cursor-pointer px-2 py-1 text-[11px] font-mono rounded border transition-all ${
              showVwap ? "bg-teal-50 border-teal-300 text-teal-700" : "bg-gray-50 border-gray-200 text-gray-500"
            }`}
          >
            VWAP
          </button>
        </div>
      </div>

      {/* Main interactive SVG Container and scales rendering */}
      <div ref={chartContainerRef} className="relative w-full overflow-x-auto select-none scrollbar-thin pb-2">
        
        {/* Render overlay value card of hovering index results */}
        {currentInd && (
          <div className="sticky left-4 top-2 z-10 flex flex-wrap items-center gap-x-2.5 gap-y-1 p-2 bg-white/95 backdrop-blur-sm border border-gray-100 rounded-lg shadow-sm text-[10px] font-mono text-slate-500 max-w-[90%] md:max-w-none">
            {showEma9 && (
              <span>9-EMA: <b className="text-amber-500">{currentInd.ema9?.toFixed(2)}</b></span>
            )}
            {showEma21 && (
              <span>21-EMA: <b className="text-sky-500">{currentInd.ema21?.toFixed(2)}</b></span>
            )}
            {showEma50 && (
              <span>50-EMA: <b className="text-indigo-500">{currentInd.ema50?.toFixed(2)}</b></span>
            )}
            {showEma200 && (
              <span>200-EMA: <b className="text-rose-500">{currentInd.ema200?.toFixed(2)}</b></span>
            )}
            {showBB && (
              <span>Bands: <b className="text-purple-600">[{currentInd.bbLower?.toFixed(1)}-{currentInd.bbUpper?.toFixed(1)}]</b></span>
            )}
            {showVwap && (
              <span>VWAP: <b className="text-teal-600">{currentInd.vwap?.toFixed(2)}</b></span>
            )}
          </div>
        )}
 
        <svg
          className="w-full min-w-[750px] h-auto cursor-crosshair focus:outline-none"
          viewBox={`0 0 ${width} ${totalHeight}`}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* DEFINITIONS FOR STYLING AND DECORATION */}
          <defs>
            <linearGradient id="bbAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(168, 85, 247, 0.08)" />
              <stop offset="100%" stopColor="rgba(168, 85, 247, 0.03)" />
            </linearGradient>
            <linearGradient id="greenCandleGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>
            <linearGradient id="redCandleGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>

          {/* 1. MAIN PRICE PANE GRID LINES AND LABELS */}
          {Array.from({ length: 6 }).map((_, idx) => {
            const range = yRange.max - yRange.min;
            const priceVal = yRange.min + (idx / 5) * range;
            const yPos = getYPos(priceVal);

            return (
              <g key={`grid-${idx}`} className="opacity-40">
                {/* Horizontal reference grid lines */}
                <line
                  x1={paddingLeft}
                  y1={yPos}
                  x2={width - paddingRight}
                  y2={yPos}
                  stroke="#e2e8f0"
                  strokeWidth="1"
                  strokeDasharray="2,3"
                />
                
                {/* Right hand axis price labels */}
                <text
                  x={width - paddingRight + 6}
                  y={yPos + 4}
                  fill="#94a3b8"
                  fontSize="9px"
                  fontFamily="monospace"
                  textAnchor="start"
                >
                  {priceVal.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Vertical Time Lines grids (At 12 candles gap) */}
          {candles.map((c, i) => {
            if (i % 16 !== 0) return null;
            const xPos = getX(i);
            return (
              <g key={`v-grid-${i}`} className="opacity-40">
                <line
                  x1={xPos}
                  y1={paddingTop}
                  x2={xPos}
                  y2={paddingTop + mainHeight}
                  stroke="#e2e8f0"
                  strokeWidth="1"
                  strokeDasharray="2,3"
                />
                <text
                  x={xPos}
                  y={paddingTop + mainHeight + 14}
                  fill="#94a3b8"
                  fontSize="9px"
                  textAnchor="middle"
                >
                  {formatTime(c.time)}
                </text>
              </g>
            );
          })}

          {/* BACKGROUND Bollinger Bands Filled Shading Area */}
          {showBB && bbFillArea && (
            <path d={bbFillArea} fill="url(#bbAreaGrad)" stroke="none" />
          )}

          {/* BOLLINGER BANDS UPPER / LOWER OVERLAY CHANNELS */}
          {showBB && bbUpperPath && (
            <path d={bbUpperPath} fill="none" stroke="#c084fc" strokeWidth="1" opacity="0.8" strokeDasharray="3,2" />
          )}
          {showBB && bbLowerPath && (
            <path d={bbLowerPath} fill="none" stroke="#c084fc" strokeWidth="1" opacity="0.8" strokeDasharray="3,2" />
          )}

          {/* VWAP overlays */}
          {showVwap && vwapPath && (
            <path d={vwapPath} fill="none" stroke="#14b8a6" strokeWidth="1.2" opacity="0.75" />
          )}

          {/* EMA INTEGRATIONS */}
          {showEma9 && ema9Path && (
            <path d={ema9Path} fill="none" stroke="#f59e0b" strokeWidth="1.2" opacity="0.85" />
          )}
          {showEma21 && ema21Path && (
            <path d={ema21Path} fill="none" stroke="#0ea5e9" strokeWidth="1.2" opacity="0.85" />
          )}
          {showEma50 && ema50Path && (
            <path d={ema50Path} fill="none" stroke="#6366f1" strokeWidth="1.2" opacity="0.85" />
          )}
          {showEma200 && ema200Path && (
            <path d={ema200Path} fill="none" stroke="#f43f5e" strokeWidth="1.2" opacity="0.85" />
          )}

          {/* CANDLESTICKS BODY AND SHADOW DRAWINGS */}
          {candles.map((c, i) => {
            const x = getX(i);
            const openY = getYPos(c.open);
            const closeY = getYPos(c.close);
            const highY = getYPos(c.high);
            const lowY = getYPos(c.low);
            
            const isBullish = c.close >= c.open;
            const strokeColor = isBullish ? "#10b981" : "#ef4444";
            
            const candleWidth = Math.max(3, (drawableWidth / candles.length) * 0.7);

            return (
              <g key={`candle-${i}`}>
                {/* Upper and Lower shadow wicks */}
                <line
                  x1={x}
                  y1={highY}
                  x2={x}
                  y2={lowY}
                  stroke={strokeColor}
                  strokeWidth="1.2"
                />
                
                {/* Candle body rect */}
                <rect
                  x={x - candleWidth / 2}
                  y={Math.min(openY, closeY)}
                  width={candleWidth}
                  height={Math.max(1, Math.abs(openY - closeY))}
                  fill={isBullish ? "url(#greenCandleGrad)" : "url(#redCandleGrad)"}
                  rx="0.5"
                />
              </g>
            );
          })}

          {/* 2. LOWER OSCILLATORS PANE SECTION */}
          {/* Grids and dividers for Sub Pane */}
          <g>
            <line
              x1={paddingLeft}
              y1={paddingTop + mainHeight + gap}
              x2={width - paddingRight}
              y2={paddingTop + mainHeight + gap}
              stroke="#cbd5e1"
              strokeWidth="1"
            />
            <rect
              x={paddingLeft}
              y={paddingTop + mainHeight + gap}
              width={drawableWidth}
              height={subHeight}
              fill="#fafbfd"
              opacity="0.8"
            />
          </g>

          {/* Render lines according to selected oscillator */}
          {bottomIndicator === "RSI" && (
            <g>
              {/* Overbought / Oversold barrier bounds */}
              {[{ v: 70, color: "#fca5a5" }, { v: 50, color: "#94a3b8" }, { v: 30, color: "#86efac" }].map(boundary => {
                const bY = getOscillatorY(boundary.v, 0, 100);
                return (
                  <line
                    key={`rsi-${boundary.v}`}
                    x1={paddingLeft}
                    y1={bY}
                    x2={width - paddingRight}
                    y2={bY}
                    stroke={boundary.color}
                    strokeWidth="1"
                    strokeDasharray="3,3"
                  />
                );
              })}

              {/* RSI Chart line */}
              {continuousIndicators.length > 0 && (
                <path
                  d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.rsi, 0, 100).toFixed(1)}`).join(" L ")}
                  fill="none"
                  stroke="#8b5cf6"
                  strokeWidth="1.2"
                />
              )}
              {/* Y Axis markings */}
              <text x={width - paddingRight + 6} y={getOscillatorY(70, 0, 100) + 3} fill="#94a3b8" fontSize="8px" fontFamily="monospace">70</text>
              <text x={width - paddingRight + 6} y={getOscillatorY(50, 0, 100) + 3} fill="#94a3b8" fontSize="8px" fontFamily="monospace">50</text>
              <text x={width - paddingRight + 6} y={getOscillatorY(30, 0, 100) + 3} fill="#94a3b8" fontSize="8px" fontFamily="monospace">30</text>
            </g>
          )}

          {bottomIndicator === "MACD" && (
            <g>
              {/* Zero line */}
              <line
                x1={paddingLeft}
                y1={getOscillatorY(0, -2, 2)}
                x2={width - paddingRight}
                y2={getOscillatorY(0, -2, 2)}
                stroke="#cbd5e1"
                strokeWidth="1"
              />

              {/* Histogram bars */}
              {continuousIndicators.map((ind, i) => {
                const topY = getOscillatorY(ind.macdHist, -2, 2);
                const baselineY = getOscillatorY(0, -2, 2);
                const x = getX(i);
                const barWidth = Math.max(1.5, (drawableWidth / candles.length) * 0.4);
                return (
                  <line
                    key={`macd-hist-${i}`}
                    x1={x}
                    y1={baselineY}
                    x2={x}
                    y2={topY}
                    stroke={ind.macdHist >= 0 ? "#10b981" : "#ef4444"}
                    strokeWidth={barWidth}
                    opacity="0.8"
                  />
                );
              })}

              {/* MACD and Signal lines */}
              {continuousIndicators.length > 0 && (
                <>
                  <path
                    d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.macd, -2, 2).toFixed(1)}`).join(" L ")}
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="1"
                  />
                  <path
                    d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.macdSignal, -2, 2).toFixed(1)}`).join(" L ")}
                    fill="none"
                    stroke="#ea580c"
                    strokeWidth="1"
                    strokeDasharray="2,2"
                  />
                </>
              )}
            </g>
          )}

          {bottomIndicator === "STOCH" && (
            <g>
              {/* Boundaries */}
              <line x1={paddingLeft} y1={getOscillatorY(80, 0, 100)} x2={width - paddingRight} y2={getOscillatorY(80, 0, 100)} stroke="#fca5a5" strokeWidth="1" strokeDasharray="3,3" />
              <line x1={paddingLeft} y1={getOscillatorY(20, 0, 100)} x2={width - paddingRight} y2={getOscillatorY(20, 0, 100)} stroke="#86efac" strokeWidth="1" strokeDasharray="3,3" />

              {/* Stochastic lines: %K and %D */}
              {continuousIndicators.length > 0 && (
                <>
                  <path
                    d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.stochK, 0, 100).toFixed(1)}`).join(" L ")}
                    fill="none"
                    stroke="#db2777"
                    strokeWidth="1"
                  />
                  <path
                    d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.stochD, 0, 100).toFixed(1)}`).join(" L ")}
                    fill="none"
                    stroke="#fca5a5"
                    strokeWidth="1"
                  />
                </>
              )}
              <text x={width - paddingRight + 6} y={getOscillatorY(80, 0, 100) + 3} fill="#94a3b8" fontSize="8px" fontFamily="monospace">80</text>
              <text x={width - paddingRight + 6} y={getOscillatorY(20, 0, 100) + 3} fill="#94a3b8" fontSize="8px" fontFamily="monospace">20</text>
            </g>
          )}

          {bottomIndicator === "ATR" && (
            <g>
              {continuousIndicators.length > 0 && (
                <path
                  d={"M " + continuousIndicators.map((ind, i) => `${getX(i).toFixed(1)},${getOscillatorY(ind.atr, 0, Math.max(...continuousIndicators.map(c => c.atr)) * 1.1).toFixed(1)}`).join(" L ")}
                  fill="none"
                  stroke="#ea580c"
                  strokeWidth="1.2"
                />
              )}
            </g>
          )}

          {/* 3. INTERACTIVE CORNER GRAPHICAL CROSSHAIR LINES */}
          {mouseCoords && mouseCoords.x >= paddingLeft && mouseCoords.x <= width - paddingRight && (
            <g>
              {/* Vertical Crosshair tracking line */}
              <line
                x1={mouseCoords.x}
                y1={paddingTop}
                x2={mouseCoords.x}
                y2={totalHeight - paddingBottom}
                stroke="#64748b"
                strokeWidth="0.8"
                strokeDasharray="4,4"
                opacity="0.8"
              />
              
              {/* Horizontal Crosshair tracking line (Only inside the main price chart) */}
              {mouseCoords.y >= paddingTop && mouseCoords.y <= paddingTop + mainHeight && (
                <line
                  x1={paddingLeft}
                  y1={mouseCoords.y}
                  x2={width - paddingRight}
                  y2={mouseCoords.y}
                  stroke="#64748b"
                  strokeWidth="0.8"
                  strokeDasharray="4,4"
                  opacity="0.8"
                />
              )}
            </g>
          )}
        </svg>
      </div>

      {/* Selector pane keys for sub oscillator panel */}
      <div className="flex flex-wrap gap-1 bg-gray-50 p-1 rounded-xl w-full sm:w-fit mt-4 border border-gray-100">
        <button
          onClick={() => setBottomIndicator("RSI")}
          className={`cursor-pointer px-3 py-1 text-xs font-medium rounded-lg transition-all ${
            bottomIndicator === "RSI" ? "bg-white text-slate-900 shadow-sm" : "text-gray-500 hover:text-slate-800"
          }`}
        >
          RSI (14)
          {currentInd && <span className="ml-1.5 font-mono font-semibold text-[11px] text-purple-600">{currentInd.rsi?.toFixed(1)}</span>}
        </button>
        <button
          onClick={() => setBottomIndicator("MACD")}
          className={`cursor-pointer px-3 py-1 text-xs font-medium rounded-lg transition-all ${
            bottomIndicator === "MACD" ? "bg-white text-slate-900 shadow-sm" : "text-gray-500 hover:text-slate-800"
          }`}
        >
          MACD (12,26,9)
          {currentInd && <span className="ml-1.5 font-mono text-[10px] text-blue-600">{currentInd.macd?.toFixed(2)}</span>}
        </button>
        <button
          onClick={() => setBottomIndicator("STOCH")}
          className={`cursor-pointer px-3 py-1 text-xs font-medium rounded-lg transition-all ${
            bottomIndicator === "STOCH" ? "bg-white text-slate-900 shadow-sm" : "text-gray-500 hover:text-slate-800"
          }`}
        >
          Stochastic
          {currentInd && <span className="ml-1.5 font-mono text-[10px] text-pink-600">{currentInd.stochK?.toFixed(1)}</span>}
        </button>
        <button
          onClick={() => setBottomIndicator("ATR")}
          className={`cursor-pointer px-3 py-1 text-xs font-medium rounded-lg transition-all ${
            bottomIndicator === "ATR" ? "bg-white text-slate-900 shadow-sm" : "text-gray-500 hover:text-slate-800"
          }`}
        >
          ATR (14)
          {currentInd && <span className="ml-1.5 font-mono text-[10px] text-orange-600">{currentInd.atr?.toFixed(4)}</span>}
        </button>
      </div>
    </div>
  );
}
