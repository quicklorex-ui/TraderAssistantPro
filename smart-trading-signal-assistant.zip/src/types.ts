export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface TechnicalIndicators {
  price: number;
  ema9: number;
  ema21: number;
  ema50: number;
  ema200: number;
  rsi: number;
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
  };
  bollingerBands: {
    upper: number;
    middle: number;
    lower: number;
  };
  stochastic: {
    k: number;
    d: number;
  };
  adx: number;
  atr: number;
  vwap: number;
  pivotPoints: {
    p: number;
    r1: number;
    s1: number;
    r2: number;
    s2: number;
    r3: number;
    s3: number;
  };
  localSwing: {
    high: number;
    low: number;
  };
}

export interface LiquidityAnalysis {
  spreadPercent: number;
  volume24h: number;
  depthLevel: string;
  bidPrice: number;
  askPrice: number;
}

export interface SentimentAnalysis {
  score: number;
  label: string;
  summary: string;
  keyNews: string[];
}

export interface SmartSignalResponse {
  symbol: string;
  price: number;
  decision: "BUY" | "SELL" | "HOLD";
  confidence: number;
  entryPrice: number;
  takeProfit: number;
  stopLoss: number;
  estimatedWindow: string;
  estimatedDuration: string;
  liquidityAnalysis: LiquidityAnalysis;
  sentiment: SentimentAnalysis;
  reasoning: string[];
}
